#pragma once
#include "Camera.h"
class GameObject;

class Rigidbody
{
private:
    Vector2D<float> velocity{ 0,0 };

    float gravityScale = 1.0f;
    bool useGravity = true;	//�d�͂��g�����ǂ���

	GameObject* owner = nullptr;

	bool isDestroyed = false;
	bool isStatic = false;
	bool isGround = false;

	Vector2D<float> velocityThreshold{ 0.01f, 0.01f }; // ���x��臒l

	float linearDamping = 0.1f; // ���x�����̌W��
public:

	Rigidbody() = default;
	Rigidbody(bool _useGravity) : useGravity(_useGravity) {}

#pragma region �Q�b�^�[�Z�b�^�[

	Rigidbody* SetVelocity(const Vector2D<float>& v) { 
		velocity = v; 
		return this;
	}
	Vector2D<float> GetVelocity() const { return velocity; }

	Rigidbody* SetGravityScale(float scale) {
		gravityScale = scale;
		return this;
	}
	float GetGravityScale() const { return gravityScale; }

	Rigidbody* SetUseGravity(bool use) {
		useGravity = use;
		return this;
	}
	bool IsUsingGravity() const { return useGravity; }

	GameObject* GetOwner() const { return owner; }
	void SetOwner(GameObject* obj) { owner = obj; }

	Rigidbody* SetIsStatic(bool s) { 
		isStatic = s; 
		return this;
	}
	bool IsStatic() const { return isStatic; }

	Rigidbody* SetIsGround(bool g) {
		isGround = g;
		return this;
	}
	bool IsGround() const { return isGround; }

	void Destroy() { isDestroyed = true; }
	bool IsDestroyed() const { return isDestroyed; }

	/// <summary>
	/// ��C��R�̂悤�ȑ��x��������������ʂ�ݒ肷��֐�.
	/// </summary>
	/// <param name="damping">1.0 �` 0.0</param>
	Rigidbody* SetLinearDamping(float damping) {
		linearDamping = damping;
		return this;
	}
	float GetLinearDamping() const { return linearDamping; }

	Rigidbody* SetVelocityThreshold(const Vector2D<float>& threshold) {
		velocityThreshold = threshold;
		return this;
	}
	Vector2D<float> GetVelocityThreshold() const { return velocityThreshold; }
#pragma endregion

	void Update(const  float &dTime);
#if RB_DEBUG
	void DebugDraw(const Camera& camera) const;
#endif // RB_DEBUG
};

