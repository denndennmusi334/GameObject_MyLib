﻿#pragma once

#include "Job.h"
#include "SceneController.h"
#include "DrawManager.h"

class BaseScene: public Job
{
protected:
    SceneController* sceneController;
    
    DrawManager drawMgr;
    Camera camera;
public:
    BaseScene(SceneController* changer);
    ~BaseScene()        override {};
    void Initialize()   override {}; //初期化.
    void Finalize()     override {}; //終了処理.
    void Update()       override {}; //更新.
    void Draw()         override {}; //描画.
    virtual void Kill() = 0;

    void AddDrawable(Drawable* obj)
    {
        drawMgr.Add(obj);
    }
}; 
